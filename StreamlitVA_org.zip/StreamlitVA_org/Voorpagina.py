#!/usr/bin/env python
# coding: utf-8

# In[2]:


import streamlit as st


# ## Titel

# In[3]:


st.title('Analyse doodsoorzaken')


# In[4]:


st.subheader('Data inspectie')


# In[6]:


st.subheader('Data Analyse')


# In[5]:


st.subheader('Statistische voorspellingen')


# In[ ]:




